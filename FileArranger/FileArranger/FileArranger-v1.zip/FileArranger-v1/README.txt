********************************************
File Arranger v1
Free to use, no lisance needed.
********************************************

v1:
-Moves files from a chosen folder to new folders sorted by years and months. 